const WEIGHTS = {
    playtime:  { personalization: 12, privacy: 4 },
    purchases: { personalization: 18, privacy: 8 },
    chat:      { personalization: 14, privacy: 9 },
    location:  { personalization: 10, privacy: 16 },
    physio:    { personalization: 30, privacy: 28 },
    device:    { personalization: 8,  privacy: 3 }
  };
  
  function computeScores(states) {
    let pSum = 0, privSum = 0, pMax = 0, privMax = 0;
    for (const key in WEIGHTS) {
      pMax += WEIGHTS[key].personalization;
      privMax += WEIGHTS[key].privacy;
      if (states[key]) {
        pSum += WEIGHTS[key].personalization;
        privSum += WEIGHTS[key].privacy;
      }
    }
    return {
      personalization: Math.round((pSum / pMax) * 100),
      privacyExposure: Math.round((privSum / privMax) * 100)
    };
  }
  
  function outcomeText(personalization, privacyExposure) {
    if (personalization >= 75 && privacyExposure >= 60) {
      return "High personalization with high privacy exposure. You gain tailored experiences but risk extensive profiling.";
    } else if (personalization >= 50 && privacyExposure < 60) {
      return "Moderate personalization and manageable privacy risk: balanced data sharing.";
    } else if (personalization < 50 && privacyExposure < 40) {
      return "Low personalization, strong privacy protection: minimal data collected.";
    } else {
      return "Mixed outcome: moderate personalization but some privacy exposure.";
    }
  }
  
  function render(personalization, privacyExposure) {
    const bar = document.getElementById("bar");
    const scoreEl = document.getElementById("personalScore");
    const outcomeEl = document.getElementById("outcomeText");
  
    bar.style.width = personalization + "%";
    const mix = Math.min(1, privacyExposure / 100);
    const r = Math.round(179 * (1 - mix) + 107 * mix);
    const g = Math.round(102 * (1 - mix) + 0 * mix);
    const b = Math.round(255 * (1 - mix) + 179 * mix);
    bar.style.background = `linear-gradient(90deg, rgba(${r},${g},${b},1), rgba(${r-60},${Math.max(g-60,0)},${Math.max(b-60,0)},0.94))`;
  
    scoreEl.textContent = personalization + "%";
    outcomeEl.textContent = outcomeText(personalization, privacyExposure);
  }
  
  document.getElementById("analyzeBtn").addEventListener("click", () => {
    const states = {
      playtime:  document.getElementById("dt-playtime").checked,
      purchases: document.getElementById("dt-purchases").checked,
      chat:      document.getElementById("dt-chat").checked,
      location:  document.getElementById("dt-location").checked,
      physio:    document.getElementById("dt-physio").checked,
      device:    document.getElementById("dt-device").checked
    };
    const scores = computeScores(states);
    render(scores.personalization, scores.privacyExposure);
  });
  
  document.getElementById("resetBtn").addEventListener("click", () => {
    document.getElementById("dt-playtime").checked = true;
    document.getElementById("dt-purchases").checked = true;
    document.getElementById("dt-chat").checked = false;
    document.getElementById("dt-location").checked = false;
    document.getElementById("dt-physio").checked = false;
    document.getElementById("dt-device").checked = true;
    document.getElementById("analyzeBtn").click();
  });
  
  window.addEventListener("load", () => {
    document.getElementById("analyzeBtn").click();
  });
  