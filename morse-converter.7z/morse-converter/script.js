/* 
Morse Code Converter II
by Dinh An Nguyen, Oct 9 2025
*/

/* -------------------------
   Data / References
   ------------------------- */
   const MORSE = {
    'A':'.-','B':'-...','C':'-.-.','D':'-..','E':'.','F':'..-.',
    'G':'--.','H':'....','I':'..','J':'.---','K':'-.-','L':'.-..',
    'M':'--','N':'-.','O':'---','P':'.--.','Q':'--.-','R':'.-.',
    'S':'...','T':'-','U':'..-','V':'...-','W':'.--','X':'-..-',
    'Y':'-.--','Z':'--..',
    '0':'-----','1':'.----','2':'..---','3':'...--','4':'....-',
    '5':'.....','6':'-....','7':'--...','8':'---..','9':'----.',
    '.':'.-.-.-', ',':'--..--','?':'..--..','!':'-.-.--','/':'-..-.',
    '(':'-.--.', ')':'-.--.-','&':'.-...',':':'---...',';':'-.-.-.',
    '=':'-...-','+':'.-.-.','-':'-....-','_':'..--.-','"':'.-..-.',
    '$':'...-..-','@':'.--.-.',' ':'/' // space -> slash for words
  };
  
  // reverse mapping (morse -> char)
  const TEXT = Object.fromEntries(Object.entries(MORSE).map(([k,v]) => [v,k]));
  
  /* -------------------------
     Utilities / Small helpers
     ------------------------- */
  const $ = id => document.getElementById(id);
  
  function isProbablyMorse(s){
    // pattern recognition: if string contains only ., -, /, whitespace it's morse
    if (!s) return false;
    const trimmed = s.trim();
    // If it contains letters beyond A-Z or digits, likely text.
    const morseChars = /^[\s.\-\/]+$/;
    return morseChars.test(trimmed);
  }
  
  function normalizeTextToMorseInput(s){
    return s.replace(/\s+/g, ' ').trim();
  }
  function normalizeMorseInput(s){
    // collapse multiple spaces between letters to single space,
    // allow spaces around slashes and convert multiple slashes to single ' / '
    return s.replace(/\s*\/\s*/g, ' / ')
            .replace(/\s+/g, ' ')
            .trim();
  }
  
  /* -------------------------
     Conversion algorithms
     ------------------------- */
  function textToMorse(text){
    // Algorithm: split into characters, look up each char; words become '/'
    return text
      .toUpperCase()
      .split('')
      .map(ch => MORSE[ch] || '?')
      .join(' ');
  }
  
  function morseToText(morse){
    // Algorithm:
    // 1) Normalize: ensure single spaces separate letters, and ' / ' separates words
    // 2) Split by ' / ' into words, then split each word by spaces into letters
    if (!morse) return '';
    const norm = normalizeMorseInput(morse);
    const wordTokens = norm.split(' / ');
    const words = wordTokens.map(word => {
      if (!word.trim()) return '';
      return word.split(' ').map(code => TEXT[code] || '?').join('');
    });
    return words.join(' ').trim();
  }
  
  /* -------------------------
     Audio playback (Web Audio API)
     ------------------------- */
  class MorsePlayer {
    constructor(wpm = 20){
      this.wpm = wpm;
      this.ctx = null;
      this.isPlaying = false;
      this._stopRequested = false;
    }
  
    setWpm(wpm){ this.wpm = Math.max(5, Math.min(40, Number(wpm))); }
  
    // length of a dot in seconds using PARIS standard: dot = 1.2 / wpm
    dotDuration(){
      return 1.2 / this.wpm;
    }
  
    // Convert morse string (normalized) into sequence of tones + pauses
    // Returns array of {type:'dot'|'dash'|'intra'|'letterGap'|'wordGap'}
    tokenize(morse){
      const norm = normalizeMorseInput(morse);
      // replace ' / ' with word gap
      const tokens = [];
      for (const ch of norm){
        if (ch === '.') tokens.push({type:'dot'});
        else if (ch === '-') tokens.push({type:'dash'});
        else if (ch === ' ') tokens.push({type:'letterGap'}); // letter gap: we'll interpret between letters
        else if (ch === '/') tokens.push({type:'wordGap'});
        // ignore other
      }
      return tokens;
    }
  
    async play(morse){
      if (this.isPlaying) { this.stop(); return; }
      if (!morse) return;
      if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
  
      this.isPlaying = true;
      this._stopRequested = false;
      const dot = this.dotDuration();
      const dash = dot * 3;
      const intra = dot; // between elements of same letter
      const letterGap = dot * 3; // between letters
      const wordGap = dot * 7;
  
      const tokens = this.tokenize(morse);
      let t = this.ctx.currentTime + 0.05; // small lead time
  
      for (let i=0;i<tokens.length && !this._stopRequested;i++){
        const tok = tokens[i];
        if (tok.type === 'dot' || tok.type === 'dash'){
          const dur = tok.type === 'dot' ? dot : dash;
          this._beep(t, dur);
          t += dur;
          // add intra-element gap if next token is dot/dash (not letter or word gap)
          const next = tokens[i+1];
          if (next && (next.type === 'dot' || next.type === 'dash')){
            t += intra;
          }
        } else if (tok.type === 'letterGap'){
          t += letterGap;
        } else if (tok.type === 'wordGap'){
          t += wordGap;
        }
      }
  
      // Wait until scheduled audio finishes or stop requested
      const endTime = t + 0.05;
      while (!this._stopRequested && this.ctx.currentTime < endTime){
        await new Promise(r => setTimeout(r, 100));
      }
      this.stop();
    }
  
    _beep(startTime, duration){
      if (!this.ctx) return;
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.frequency.value = 750; // tone frequency
      o.type = 'sine';
      g.gain.setValueAtTime(0.0001, startTime);
      g.gain.exponentialRampToValueAtTime(0.6, startTime + 0.01);
      g.gain.setValueAtTime(0.0001, startTime + duration - 0.01);
  
      o.connect(g);
      g.connect(this.ctx.destination);
      o.start(startTime);
      o.stop(startTime + duration);
    }
  
    stop(){ this._stopRequested = true; this.isPlaying = false; }
  }
  
  /* -------------------------
     State & DOM wiring
     ------------------------- */
  const player = new MorsePlayer(Number($('wpm')?.value || 20));
  const state = { history: [] };
  
  function updateWpmDisplay(){
    $('wpm-output').textContent = $('wpm').value;
  }
  
  function loadHistory(){
    try {
      const raw = localStorage.getItem('morse_history_v1');
      state.history = raw ? JSON.parse(raw) : [];
    } catch(e){ state.history = []; }
    renderHistory();
  }
  
  function saveHistory(){
    localStorage.setItem('morse_history_v1', JSON.stringify(state.history.slice(0,50)));
  }
  
  function addHistory(input, output, mode){
    state.history.unshift({time: Date.now(), input, output, mode});
    // keep a reasonable size
    if (state.history.length > 50) state.history.length = 50;
    saveHistory();
    renderHistory();
  }
  
  function renderHistory(){
    const el = $('historyList');
    el.innerHTML = '';
    if (!state.history.length){
      el.innerHTML = '<li style="color:var(--muted)">No recent conversions</li>';
      return;
    }
    for (const item of state.history){
      const li = document.createElement('li');
      li.innerHTML = `<div style="flex:1"><strong style="color:var(--accent)">${new Date(item.time).toLocaleString()}</strong>
        <div style="font-family:ui-monospace,monospace;color:var(--muted);font-size:0.9rem;margin-top:0.25rem">${escapeHtml(item.input)}</div>
        <div style="margin-top:0.25rem;color:#dffbf0">${escapeHtml(item.output)}</div></div>`;
      const useBtn = document.createElement('button');
      useBtn.textContent = 'Use';
      useBtn.title = 'Load this conversion into input';
      useBtn.addEventListener('click', ()=> {
        $('input').value = item.input;
        convertHandler();
      });
      li.appendChild(useBtn);
      el.appendChild(li);
    }
  }
  
  function clearHistory(){
    state.history = [];
    saveHistory();
    renderHistory();
  }
  
  /* -------------------------
     UI helpers & interactions
     ------------------------- */
  function escapeHtml(s){
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
  
  function setInfo(msg){
    $('information').textContent = msg || '';
  }
  
  function setOutput(text){
    $('output').textContent = text;
  }
  
  function updatePreviewDebounced(){
    if (updatePreviewDebounced._timer) clearTimeout(updatePreviewDebounced._timer);
    updatePreviewDebounced._timer = setTimeout(updatePreview, 200);
  }
  
  function updatePreview(){
    const input = $('input').value;
    const mode = document.querySelector('input[name="mode"]:checked').value;
    let previewText = '';
    if (!input) {
      $('preview').textContent = '';
      return;
    }
    const chosenMode = mode === 'auto' ? (isProbablyMorse(input) ? 'morseToText' : 'textToMorse') : mode;
    if (chosenMode === 'textToMorse') previewText = textToMorse(input);
    else previewText = morseToText(input);
    $('preview').textContent = previewText;
  }
  
  /* -------------------------
     Main conversion handler
     ------------------------- */
  function convertHandler(){
    const raw = $('input').value || '';
    const modeChoice = document.querySelector('input[name="mode"]:checked').value;
    if (!raw.trim()){
      setInfo('⚠️ Please enter text or Morse code first.');
      setOutput('');
      return;
    }
  
    // Decide mode
    let mode = modeChoice;
    if (modeChoice === 'auto'){
      mode = isProbablyMorse(raw) ? 'morseToText' : 'textToMorse';
    }
  
    let input = raw;
    let output = '';
    if (mode === 'textToMorse'){
      input = normalizeTextToMorseInput(raw);
      output = textToMorse(input);
      setInfo(`${input.toUpperCase()} → Morse`);
    } else {
      input = normalizeMorseInput(raw);
      output = morseToText(input);
      setInfo(`Morse → ${output}`);
    }
  
    setOutput(output);
    addHistory(input, output, mode);
  
    // auto-play?
    if ($('autoPlay').checked && mode === 'textToMorse'){
      player.setWpm(Number($('wpm').value));
      player.play(output);
    }
  }
  
  /* -------------------------
     Copy, Clear, Examples etc.
     ------------------------- */
  function copyOutput(){
    const text = $('output').textContent || '';
    if (!text) { alert('Nothing to copy'); return; }
    navigator.clipboard.writeText(text).then(()=> {
      setInfo('Copied output to clipboard ✅');
    }).catch(()=> {
      setInfo('Copy failed. Use Ctrl/Cmd+C on the output area.');
    });
  }
  
  function clearAll(){
    $('input').value = '';
    setOutput('');
    setInfo('');
    $('preview').textContent = '';
  }
  
  /* -------------------------
     Event wiring and init
     ------------------------- */
  function wire(){
    // wire buttons
    $('convertBtn').addEventListener('click', convertHandler);
    $('copyBtn').addEventListener('click', copyOutput);
    $('clearBtn').addEventListener('click', clearAll);
  
    // play
    $('playBtn').addEventListener('click', ()=> {
      const out = $('output').textContent || $('preview').textContent || '';
      if (!out) { setInfo('Nothing to play'); return; }
      // if current mode is morseToText, try to convert preview to morse for playback
      const mode = document.querySelector('input[name="mode"]:checked').value;
      const toPlay = (mode === 'morseToText' && !isProbablyMorse($('input').value)) ? textToMorse($('input').value) : (isProbablyMorse(out) ? out : textToMorse(out));
      player.setWpm(Number($('wpm').value));
      player.play(toPlay);
    });
  
    // wpm
    $('wpm').addEventListener('input', ()=> {
      updateWpmDisplay();
      player.setWpm(Number($('wpm').value));
    });
  
    // input events (preview)
    $('input').addEventListener('input', updatePreviewDebounced);
    document.querySelectorAll('input[name="mode"]').forEach(r=> r.addEventListener('change', updatePreview));
  
    // examples
    document.querySelectorAll('.example').forEach(btn => {
      btn.addEventListener('click', e => {
        const text = e.target.textContent.trim();
        $('input').value = text;
        convertHandler();
      });
    });
  
    // history
    $('clearHistory').addEventListener('click', ()=> {
      if (confirm('Clear conversion history?')) clearHistory();
    });
  
    // keyboard shortcuts
    window.addEventListener('keydown', (ev)=> {
      // Ctrl/Cmd + Enter -> convert
      if ((ev.ctrlKey || ev.metaKey) && ev.key === 'Enter') { ev.preventDefault(); convertHandler(); }
      // Space to stop audio when playing
      if (ev.code === 'Space'){
        if (player.isPlaying) { player.stop(); setInfo('Audio stopped'); }
      }
      // When output focused, pressing 'c' copies
      if (document.activeElement === $('output') && (ev.key === 'c' || ev.key === 'C')) {
        copyOutput();
      }
    });
  
    // clicking output focuses it for keyboard copy
    $('output').addEventListener('click', ()=> $('output').focus());
  
    // show/hide examples toggle
    $('showExamples').addEventListener('change', (e)=>{
      $('examples').style.display = e.target.checked ? 'block' : 'none';
    });
  
    // init displays
    updateWpmDisplay();
    loadHistory();
    updatePreview();
  }
  
  document.addEventListener('DOMContentLoaded', wire);
  