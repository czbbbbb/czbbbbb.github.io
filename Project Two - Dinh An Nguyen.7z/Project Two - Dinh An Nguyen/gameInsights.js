const submitBtn = document.getElementById("submit");
const exportBtn = document.getElementById("export");
const importBtn = document.getElementById("import");
const fileInput = document.getElementById("fileInput");
const summary = document.getElementById("summary");
const ctx = document.getElementById("chart").getContext("2d");
const historyBody = document.querySelector("#historyTable tbody");

// Load stored sessions or initialize empty array
let gameData = JSON.parse(localStorage.getItem("gameSessions")) || [];
let moodChart;

function getMoodGradient(avgEnjoyment, avgFrustration) {
  if (avgEnjoyment > 8) return ["#4e54c8", "#8f94fb"];
  if (avgEnjoyment > 6) return ["#43cea2", "#185a9d"];
  if (avgFrustration > 7) return ["#a40606", "#d98324"];
  return ["#3a6186", "#89253e"];
}

// Function to save a new session 
function saveData() {
  const enjoyment = parseInt(document.getElementById("enjoyment").value);
  const difficulty = parseInt(document.getElementById("difficulty").value);
  const immersion = parseInt(document.getElementById("immersion").value);
  const frustration = parseInt(document.getElementById("frustration").value);

  if ([enjoyment, difficulty, immersion, frustration].some(isNaN)) {
    summary.textContent = "⚠️ Please fill out all fields (1–10).";
    return;
  }

  const session = {
    enjoyment,      // raw number
    difficulty,     // raw number
    immersion,      // raw number
    frustration,    // raw number
    date: new Date().toLocaleString()
  };

  // Save raw data to localStorage
  gameData.push(session);
  localStorage.setItem("gameSessions", JSON.stringify(gameData));

  // Update chart
  updateChart();

  // Update session table and textual summary
  updateHistory();
  
  summarizeTrends();

  // Change background gradient based on mood pattern
  animateBackground(session);
}

// Function to calculate averages
function summarizeTrends() {
  const avgEnjoyment = average(gameData.map(s => s.enjoyment));
  const avgFrustration = average(gameData.map(s => s.frustration));
  const avgDifficulty = average(gameData.map(s => s.difficulty));
  const avgImmersion = average(gameData.map(s => s.immersion));

  summary.innerHTML = `
  Avg Enjoyment: ${avgEnjoyment.toFixed(1)} | 
  Difficulty: ${avgDifficulty.toFixed(1)} | 
  Immersion: ${avgImmersion.toFixed(1)} | 
  Frustration: ${avgFrustration.toFixed(1)}<br>
  ${
    avgFrustration > 7
      ? "⚠️ Players seem frustrated — consider lowering challenge intensity."
      : avgEnjoyment > 7
      ? "✅ Great! Players are enjoying the experience."
      : "🕹️ Balanced results — test further to find improvement areas."
  }`;
}

function animateBackground(session) {
  const [color1, color2] = getMoodGradient(session.enjoyment, session.frustration);
  document.body.style.background = `linear-gradient(120deg, ${color1}, ${color2})`;
}

function updateChart() {
  const labels = gameData.map(s => s.date);
  const enjoymentData = gameData.map(s => s.enjoyment);
  const frustrationData = gameData.map(s => s.frustration);
  const immersionData = gameData.map(s => s.immersion);

  if (moodChart) moodChart.destroy();

  moodChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        { label: "Enjoyment", data: enjoymentData, borderColor: "#43cea2", tension: 0.4 },
        { label: "Frustration", data: frustrationData, borderColor: "#ff5e62", tension: 0.4 },
        { label: "Immersion", data: immersionData, borderColor: "#8f94fb", tension: 0.4 }
      ]
    },
    options: {
      scales: {
        y: { beginAtZero: true, max: 10 }
      },
      plugins: {
        legend: { labels: { color: "#fff" } }
      }
    }
  });
}

function updateHistory() {
  historyBody.innerHTML = "";
  gameData.forEach(s => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${s.date}</td><td>${s.enjoyment}</td><td>${s.difficulty}</td><td>${s.immersion}</td><td>${s.frustration}</td>`;
    historyBody.appendChild(row);
  });
}

function exportData() {
  const blob = new Blob([JSON.stringify(gameData, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "game_data.json";
  a.click();
}

function importData(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    gameData = JSON.parse(event.target.result);
    localStorage.setItem("gameSessions", JSON.stringify(gameData));
    updateChart();
    updateHistory();
    summarizeTrends();
  };
  reader.readAsText(file);
}

// Helper function to compute average
function average(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

submitBtn.addEventListener("click", saveData);
exportBtn.addEventListener("click", exportData);
importBtn.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", importData);

updateChart();
updateHistory();
summarizeTrends();
