const data = {"labels":["Burnside","Hegewisch","North Park","Fuller Park","West Elsdon","Kenwood","..."],"values":[100.0,100.0,100.0,100.0,100.0,90.0,/* ... up to top 20 */]};

const ctx = document.getElementById('chart').getContext('2d');

function createGradient(ctx, chartArea, index, total) {
  const {left, right, top, bottom} = chartArea;
  const g = ctx.createLinearGradient(0, top, 0, bottom);
  const hue = Math.round(260 - (index / total) * 180); // varies by index
  const color1 = `hsl(${hue} 90% 65%)`;
  const color2 = `hsl(${(hue + 40) % 360} 90% 55%)`;
  g.addColorStop(0, color1);
  g.addColorStop(1, color2);
  return g;
}

const labels = data.labels;
const values = data.values;

const config = {
  type: 'bar',
  data: {
    labels: labels,
    datasets: [{
      label: "CHACSJY_2023-2024",
      data: values,
      backgroundColor: [],
      borderRadius: 8,
      barThickness: 18,
      maxBarThickness: 34
    }]
  },
  options: {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: true }
    },
    scales: {
      x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.06)' } },
      y: { ticks: { color: '#333' }, grid: { display: false } }
    },
    animation: {
      onComplete: function(){ },
      delay: 300,
      easing: 'easeOutQuart'
    }
  },
  plugins: [{
    id: 'applyGradients',
    beforeDatasetsDraw(chart, args, options) {
      const ctx = chart.ctx;
      const chartArea = chart.chartArea;
      const dataset = chart.data.datasets[0];
      const total = dataset.data.length;
      dataset.backgroundColor = dataset.data.map((v,i) => createGradient(ctx, chartArea, i, total));
    }
  }]
};

const chart = new Chart(ctx, config);
