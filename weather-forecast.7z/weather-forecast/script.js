const nwsUrl = 'https://api.weather.gov/gridpoints/LOT/38,77/forecast';

fetch(nwsUrl)
    .then(response => response.json())
    .then(data => {
        const times = [];
        const temperatures = [];
        const colors = [];

        data.properties.periods.forEach(period => {
            times.push(formatTime(period.startTime));
            temperatures.push(period.temperature);
            colors.push(getColorForTemperature(period.temperature));
        });

        createBarChart(times, temperatures, colors);
    })
    .catch(error => console.error('Error fetching weather data:', error));

function formatTime(isoTime) {
    const date = new Date(isoTime);
    return date.toLocaleString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
}

function getColorForTemperature(temp) {
    if (temp <= 50) return "rgba(54, 162, 235, 0.7)";   
    else if (temp <= 75) return "rgba(75, 192, 192, 0.7)"; 
    else return "rgba(255, 99, 132, 0.7)";              
}

function createBarChart(times, temps, colors) {
    const ctx = document.getElementById("weatherChart").getContext("2d");

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: times,
            datasets: [{
                label: "Temperature (°F)",
                data: temps,
                backgroundColor: colors,
                borderColor: colors.map(color => color.replace('0.7', '1')),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: false }
            },
            plugins: {
                tooltip: { mode: 'index', intersect: false },
                legend: { display: false }
            }
        }
    });
}
